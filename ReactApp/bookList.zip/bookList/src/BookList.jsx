import { Link } from "react-router-dom";

export default function BookList({ books }) {
  return (
    <div style={{ textAlign: "center" }}>
      <h2>Book Explorer</h2>
      {books.map((b) => (
        <div key={b.id} style={{ margin: "10px" }}>
          <h3>{b.title}</h3>
          <p>Author: {b.author}</p>
          <Link to={`/book/${b.id}`}>View Details</Link>
        </div>
      ))}
    </div>
  );
}
